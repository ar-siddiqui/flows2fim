package config

import (
	"testing"
)

func TestLoadConfig(t *testing.T) {
	// os.Setenv("GOCLIAPP_CAPITALIZE_NAME", "TRUE")
	// os.Setenv("GOCLIAPP_LANGUAGE", "Spanish")

	// LoadConfig()

	// if !GlobalConfig.CapitalizeName {
	// 	t.Error("Expected CapitalizeName to be true")
	// }
	// if GlobalConfig.Language != "Spanish" {
	// 	t.Errorf("Expected Language to be 'Spanish', got %s", GlobalConfig.Language)
	// }
}
