//go:build windows

package fim

var gdalMergeName = "gdal_merge"
